const express = require('express')
const { MongoClient, ObjectId } = require('mongodb')
const app = express()

// Configuração do EJS
app.set('view engine', 'ejs')
app.set('views', './views')

// Configuração para receber dados de formulários
app.use(express.urlencoded({ extended: true }))
app.use(express.json())

// Arquivos estáticos (CSS)
app.use(express.static('public'))

// Conexão com MongoDB
//const uri = "mongodb+srv://root:1234@cluster0.88gau9m.mongodb.net/?appName=Cluster0"
const uri = "mongodb://localhost:27017"
const client = new MongoClient(uri)

let db

async function conectar() {
    await client.connect()
    db = client.db("projeto-carros")
    console.log("MongoDB conectado!")
}

conectar().then(() => {
    app.listen(80, () => {
        console.log("Servidor rodando na porta 80")
    })
}).catch(err => {
    console.log("Erro ao conectar MongoDB:", err)
})
// ==================== ROTAS PRINCIPAIS ====================

app.get('/', (req, res) => {
    res.redirect('/projects')
})

app.get('/projects', (req, res) => {
    res.render('projects')
})

// ==================== USUÁRIOS ====================

app.get('/cadastro', (req, res) => {
    res.render('cadastro')
})

app.post('/cadastro', async (req, res) => {
    const { nome, login, senha } = req.body
    await db.collection('usuarios').insertOne({ nome, login, senha })
    res.redirect('/login')
})

app.get('/login', (req, res) => {
    res.render('login')
})

app.post('/login', async (req, res) => {
    const { login, senha } = req.body
    const usuario = await db.collection('usuarios').findOne({ login, senha })
    if (usuario) {
        res.redirect('/carros')
    } else {
        res.send('Login ou senha inválidos. <a href="/login">Tentar novamente</a>')
    }
})

// ==================== CARROS ====================

app.get('/carros', async (req, res) => {
    const carros = await db.collection('carros').find().toArray()
    res.render('carros', { carros })
})

app.get('/carros/gerenciar', async (req, res) => {
    const carros = await db.collection('carros').find().toArray()
    res.render('gerenciar', { carros })
})

app.post('/carros/cadastrar', async (req, res) => {
    const { marca, modelo, ano, qtde_disponivel } = req.body
    await db.collection('carros').insertOne({
        marca,
        modelo,
        ano: parseInt(ano),
        qtde_disponivel: parseInt(qtde_disponivel)
    })
    res.redirect('/carros/gerenciar')
})

app.post('/carros/remover', async (req, res) => {
    const { id } = req.body
    await db.collection('carros').deleteOne({ _id: new ObjectId(id) })
    res.redirect('/carros/gerenciar')
})

app.post('/carros/atualizar', async (req, res) => {
    const { id, qtde_disponivel } = req.body
    await db.collection('carros').updateOne(
        { _id: new ObjectId(id) },
        { $set: { qtde_disponivel: parseInt(qtde_disponivel) } }
    )
    res.redirect('/carros/gerenciar')
})

app.post('/carros/vender', async (req, res) => {
    const { id } = req.body
    await db.collection('carros').updateOne(
        { _id: new ObjectId(id) },
        { $inc: { qtde_disponivel: -1 } }
    )
    res.redirect('/carros')
})

