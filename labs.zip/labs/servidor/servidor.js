
var http = require('http');
var express = require('express');
require('colors');
var bodyParser = require('body-parser');

var app = express();
app.use(express.static('./public'));
app.use(bodyParser.urlencoded({ extended: false}))
app.use(bodyParser.json())
app.set('view engine', 'ejs')
app.set('views', './views');

var server = http.createServer(app);
server.listen(80);

console.log('Servidor rodando ...'.rainbow);

app.get('/', function (requisicao, resposta){
  resposta.redirect('../Att01/index.html')
})

app.get('/login', function (requisicao, resposta){
var nome = requisicao.query.info;
var email = requisicao.query.info;
var senha = requisicao.query.info;
console.log(nome);
console.log(email);
console.log(senha);
})

app.get('/cadastro',function (requisicao, resposta){
var nome = requisicao.query.nome;
var email = requisicao.query.email;
var senha = requisicao.query.senha;

resposta.render('resposta', {nome, email, senha})
})
app.post('/blog',function(req, resp){
    console.log('Requisição recebida por post');

    var titulo = req.body.titulo;
    var resumo = req.body.resumo;
    var conteudo = req.body.conteudo;
    console.log(titulo, body, conteudo)
    resp.render('blog.ejs', {metodo:"POST", titulo, resumo, conteudo});

})
