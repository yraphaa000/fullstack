const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");

const img = new Image();
img.src = "pou.jpg";
let mouseX = 150;
let mouseY = 150;
const imgSize = 50;
canvas.addEventListener("mousemove", (e) => {
  const rect = canvas.getBoundingClientRect();
  mouseX = e.clientX - rect.left;
  mouseY = e.clientY - rect.top;
});
function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  let x = mouseX - imgSize / 2;
  let y = mouseY - imgSize / 2;
  x = Math.max(0, Math.min(canvas.width - imgSize, x));
  y = Math.max(0, Math.min(canvas.height - imgSize, y));
  ctx.drawImage(img, x, y, imgSize, imgSize);
  requestAnimationFrame(draw);
}
img.onload = () => {
  draw();
};


