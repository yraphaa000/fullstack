import sqlite3

# Nome do arquivo onde o banco SQLite será salvo
NOME_BANCO = "loja.sqlite"

def conectar():
    """
    Cria uma conexão com o banco SQLite.
    Se o arquivo loja.sqlite não existir, ele será criado.
    """
    conexao = sqlite3.connect(NOME_BANCO)

    # Faz o SQLite retornar linhas mais fáceis de acessar,
    # permitindo usar linha["nome"] em vez de linha[1].
    conexao.row_factory = sqlite3.Row

    return conexao
def criar_tabela():
    conexao = conectar()
    cursor = conexao.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Clientes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            email TEXT NOT NULL,
            cidade TEXT NOT NULL
        )
    """)

    conexao.commit()
    conexao.close()

    print("Tabela Clientes criada com sucesso.")
def inserir_produto(nome, email, cidade):
    conexao = conectar()
    cursor = conexao.cursor()

    # O uso de '?' é fundamental para evitar SQL Injection
    cursor.execute("""
        INSERT INTO Clientes (nome, email, cidade)
        VALUES (?, ?, ?)
    """, (nome, email, cidade))

    conexao.commit()
    conexao.close()

    print(f"Produto '{nome}' inserido com sucesso.")
def listar_produtos():
    conexao = conectar()
    cursor = conexao.cursor()

    cursor.execute("""
        SELECT id, nome, email, cidade
        FROM Cliente
        ORDER BY id
    """)

    # fetchall() pega todos os resultados da consulta
    produtos = cursor.fetchall()

    conexao.close()

    print("\nLista de Cliente:")
    if not produtos:
        print("Nenhum Cliente cadastrado.")
        return

    for produto in produtos:
        print(
            f"ID: {produto['id']} | "
            f"Nome: {produto['nome']} | "
            f"Email: {produto['email']} | "
            f"Cidade: {produto['cidade']} | "
        )
def atualizar_quantidade(id_produto, nova_quantidade):
    conexao = conectar()
    cursor = conexao.cursor()

    cursor.execute("""
        UPDATE Cliente
        SET email = ?
        WHERE id = ?
    """, (nova_quantidade, id_produto))

    conexao.commit()
    conexao.close()

    print(f"Quantidade d ID {id_produto} atualizada para {nova_quantidade}.")

def apagar_produto(id_produto):
    conexao = conectar()
    cursor = conexao.cursor()

    cursor.execute("""
        DELETE FROM produtos
        WHERE id = ?
    """, (id_produto,))

    conexao.commit()
    conexao.close()

    print(f"Produto ID {id_produto} apagado com sucesso.")
def apagar_produto(id_produto):
    conexao = conectar()
    cursor = conexao.cursor()

    cursor.execute("""
        DELETE FROM produtos
        WHERE id = ?
    """, (id_produto,))

    conexao.commit()
    conexao.close()

    print(f"Produto ID {id_produto} apagado com sucesso.")
# Programa principal
if __name__ == "__main__":
    print("--- Iniciando o sistema de loja (SQLite) ---")
    
    # 1. Criar a tabela
    criar_tabela()

    # 2. Inserir alguns produtos
    inserir_produto("Teclado Mecânico", "Informática", 250.00, 15)
    inserir_produto("Mouse Sem Fio", "Informática", 85.50, 30)
    inserir_produto("Caderno Universitário", "Papelaria", 25.90, 50)

    # 3. Listar para ver se inseriu corretamente
    listar_produtos()

    # 4. Atualizar a quantidade do Teclado (ID 1)
    atualizar_quantidade(1, 10)

    # 5. Listar novamente para ver a atualização
    listar_produtos()

    # 6. Apagar o Mouse (ID 2)
    apagar_produto(2)

    # 7. Listar pela última vez
    listar_produtos()
    
    print("\n--- Fim da execução ---")