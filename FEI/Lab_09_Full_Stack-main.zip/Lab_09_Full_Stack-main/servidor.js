const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const db = require('./database');
const chalk = require('chalk')
const app = express();

// porta 80
const PORT = 80;

///mostrar as páginas do public
app.use(express.static('public'))


// configuração do EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// arquivos estáticos
app.use(express.static(path.join(__dirname, 'public')));

// body parser
app.use(bodyParser.urlencoded({ extended: true }));

// endereço padrão direciona para o meu portifólio 
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'testefurgao.html'));
});

// rota blog
app.get('/blog', (req, res) => {
    db.buscarPosts((posts) => {
        res.render('blog', { posts });
    });
});

// rota cadastrar post
app.get('/cadastrar_post', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'cadastrar_post.html'));
});

// salvar post
app.post('/salvar_post', (req, res) => {

    const titulo = req.body.titulo;
    const resumo = req.body.resumo;
    const conteudo = req.body.conteudo;

    db.cadastrarPost(titulo, resumo, conteudo, () => {
        res.redirect('/blog');
    });
});




app.use(express.static('public')) //parte para que deixa arquivos estaticos acessivéis no public 

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'testefurgao.html'))
})


app.listen(PORT, () => {
    console.log(
        chalk.green('\n✅ Servidor rodando!') +
        chalk.blue(`\n🌐 http://localhost:${PORT}\n`)
    );
});