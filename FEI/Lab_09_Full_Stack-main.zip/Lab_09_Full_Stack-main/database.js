
const sqlite3 = require('sqlite3').verbose();

//cria o banco de dados
const db = new sqlite3.Database('banco.db');

// criar tabela (serialixe é usado para comando em sequencia)
db.serialize(() => {
    db.run(`
        CREATE TABLE IF NOT EXISTS posts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            titulo TEXT,
            resumo TEXT,
            conteudo TEXT
        )
    `);
});

// cadastrar post
function cadastrarPost(titulo, resumo, conteudo, callback) {

    db.run(
        'INSERT INTO posts (titulo, resumo, conteudo) VALUES (?, ?, ?)',
        [titulo, resumo, conteudo],
        callback
    );
}

// ver todos os posts
function buscarPosts(callback) {

    db.all('SELECT * FROM posts', [], (err, rows) => {
        if (err) {
            console.log(err);
            callback([]);
        } else {
            callback(rows);
        }
    });
}

module.exports = {
    cadastrarPost,
    buscarPosts
};