let anima = document.getElementById("anima");
let ctb = anima.getContext("2d");

let retangulo = {
    x: 0,
    y: 0,
    altura: 50,
    largura: 50,
    cor: 'red',
    desenha: function () {
        ctb.beginPath();
        ctb.strokeStyle = "blue";
        ctb.fillStyle = this.cor;
        ctb.fillRect(this.x, this.y, this.largura, this.altura);
        ctb.stroke();
        ctb.closePath();
    }
};

let aux = 1;
let mouseNoCanvas = false; 

function animacao() {
    ctb.clearRect(0, 0, anima.width, anima.height);

    if (!mouseNoCanvas) {

        if (retangulo.x >= 300 - retangulo.largura) {
            aux = -1;
        } else if (retangulo.x <= 0) {
            aux = 1;
        }
        retangulo.x += aux;
    }

    retangulo.desenha();
    requestAnimationFrame(animacao);
}

animacao();


anima.addEventListener('mousemove', function (evento) {
    mouseNoCanvas = true;
    let rect = anima.getBoundingClientRect();
    retangulo.x = evento.clientX - rect.left;
    retangulo.y = evento.clientY - rect.top;
});


anima.addEventListener('mouseleave', function () {
    mouseNoCanvas = false;
});