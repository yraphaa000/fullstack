let text = document.getElementById("text");
let ctc = text.getContext("2d");

document.fonts.load("90px Kablammo").then(function () {
    ctc.beginPath();
    ctc.font = "90px Kablammo";
    ctc.fillStyle = "rgb(255, 255, 255)";
    ctc.strokeStyle = "#79be53";
    ctc.lineWidth = 5;
    ctc.shadowColor = 'black';
    ctc.shadowBlur = 10;
    ctc.shadowOffsetY = 5;
    ctc.strokeText("Canvas", 160, 100);
    ctc.fillText("Canvas", 160, 100);
    ctc.closePath();
});






