let text2 = document.getElementById("text2");
let ctd = text2.getContext("2d");

ctd.beginPath();
ctd.font = "70px dialog";
ctd.fillStyle = "rgb(221, 113, 12)";
ctd.lineWidth = 3;
ctd.strokeStyle = "rgb(255, 0, 0)";
ctd.strokeText("Retangulo", 20, 70);
ctd.fillText("Retangulo", 20, 70);
ctd.closePath();

ctd.beginPath();
ctd.font = "70px dialog";
ctd.fillStyle = "rgb(221, 113, 12)";
ctd.lineWidth = 3;
ctd.strokeStyle = "rgb(255, 0, 0)";
ctd.strokeText("Formas", 440, 70);
ctd.fillText("Formas", 440, 70);
ctd.closePath();


ctd.beginPath();
ctd.font = "70px dialog";
ctd.fillStyle = "rgb(221, 113, 12)";
ctd.lineWidth = 3;
ctd.strokeStyle = "rgb(255, 0, 0)";
ctd.strokeText("Casinha", 840, 70);
ctd.fillText("Casinha", 840, 70);
ctd.closePath();