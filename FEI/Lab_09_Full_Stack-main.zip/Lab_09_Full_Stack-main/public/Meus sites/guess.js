function verificarNumero() {
    let valorDigitado = document.getElementById("numeroUsuario").value;
    let numeroUsuario = Number(valorDigitado);

    let numeroAleatorio = Math.floor(Math.random() * 11);

    let resultado = document.getElementById("resultado");
    let pagina = document.getElementById("pagina");

    if (numeroUsuario === numeroAleatorio) {
        resultado.textContent = "Parabéns! Você acertou. Número gerado: " + numeroAleatorio;
        pagina.style.setProperty("background-color", "lightgreen");
    } else {
        resultado.textContent = "Você errou. Número gerado: " + numeroAleatorio;
        pagina.style.setProperty("background-color", "red");
    }
}