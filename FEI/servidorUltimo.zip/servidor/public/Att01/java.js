 function verificar() {
      let aleatorio = Math.random();

      // Multiplicando e usando Math.floor()
      let numeroGerado = Math.floor(aleatorio * 100);

      let valorUsuario = parseInt(document.getElementById("numero").value);
      let resultado = document.getElementById("resultado");
      let box = document.getElementById("box");

      // Estrutura condicional
      if (valorUsuario === numeroGerado) {
        resultado.innerText = "Acertou! Número: " + numeroGerado;
        box.style.setProperty("background-color", "lightgreen");
      } else if (valorUsuario > numeroGerado) {
        resultado.innerText = "Errou! Seu número é MAIOR. Número: " + numeroGerado;

        // mudar fundo para vermelho
        box.style.setProperty("background-color", "red");
      } else {
        resultado.innerText = "Errou! Seu número é MENOR. Número: " + numeroGerado;

        // mudar fundo para vermelho
        box.style.setProperty("background-color", "red");
      }
    }